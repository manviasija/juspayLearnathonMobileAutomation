import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.TapOptions;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

//import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Main {

    private static AndroidDriver driver;

    public static void main(String[] args) throws MalformedURLException, Exception {

        DesiredCapabilities caps = new DesiredCapabilities();
        File app = new File("C:\\Mobile Automation\\AmazonShoppingTest\\APK\\meesho.apk");
        caps.setCapability(MobileCapabilityType.PLATFORM_NAME,"Android");
        caps.setCapability(MobileCapabilityType.DEVICE_NAME,"Pixel 6 Pro API 33");
        caps.setCapability(MobileCapabilityType.UDID,"emulator-5554");
        URL url= new URL(" http://localhost:4723/wd/hub");
        caps.setCapability("app",app.getAbsolutePath());
        driver = new AndroidDriver(url,caps);
        driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);

        String phoneNumber = "1234567890";
        String cardNumber = "4335874829550785";
        String expiryDate = "12/32";
        String cvv = "786";

        driver.findElement(By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/androidx.recyclerview.widget.RecyclerView/android.widget.FrameLayout[1]/android.widget.ImageView")).click();
        driver.findElement(By.id("com.android.permissioncontroller:id/permission_deny_button")).click();
        driver.findElement((By.id("com.meesho.supply:id/query_edit_text"))).click();
        driver.findElement((By.id("com.meesho.supply:id/query_edit_text"))).click();
        driver.findElement((By.id("com.meesho.supply:id/query_edit_text"))).sendKeys("Nike Shoes");
        driver.findElement((By.xpath("//android.widget.TextView[@index='1' and @text='nike shoes']"))).click();
        driver.findElement(By.xpath("//android.widget.TextView[@text='Modern Fabulous Men Sports Shoes']")).click();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(90));
        WebElement element3 = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("com.meesho.supply:id/primary_cta")));

        element3.click();
        driver.findElement(By.xpath("//.[@text='IND-7']")).click();
        driver.findElement(By.xpath("//.[@text='Buy Now']")).click();
        driver.findElement(By.xpath("//android.widget.EditText[@text='Phone Number']")).sendKeys(phoneNumber);
        driver.findElement((By.xpath("//.[@text='Continue']"))).click();

        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("com.meesho.supply:id/multi_cta_info_primary_cta")));

        element.click();

        WebElement element2 = wait.until(ExpectedConditions.visibilityOfElementLocated((By.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.view.ViewGroup/android.widget.FrameLayout/androidx.recyclerview.widget.RecyclerView/android.view.ViewGroup[3]/android.view.ViewGroup/android.widget.LinearLayout/android.widget.TextView"))));

        element2.click();
        driver.findElement((By.xpath("//.[@text='Add new card']"))).click();

        WebElement element5 = wait.until(ExpectedConditions.visibilityOfElementLocated((By.xpath("//android.widget.EditText[@text='Card Number']"))));

        element5.sendKeys(cardNumber);

        driver.findElement(By.id("com.meesho.supply:id/dateET")).sendKeys(expiryDate);
        driver.findElement(By.id("com.meesho.supply:id/cvv_et")).sendKeys(cvv);

        driver.findElement(By.xpath("//.[@text='Verify']")).click();
        WebElement element6 = wait.until(ExpectedConditions.visibilityOfElementLocated((By.id("com.meesho.supply:id/multi_cta_info_primary_cta"))));

        element6.click();

        driver.close();

    }
}
